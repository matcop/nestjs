export class Brand {

    id: string;
    name: string;

    createdAt: number;
    updatedAt?: number;

}
